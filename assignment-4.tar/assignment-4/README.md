# README

My submission for this assignment is `assignment4.ipynb`. The .fits files are named according to "snapshot_lr_{learning_rate}_{N_epochs}.fits" and contain the tables listing weights, gradients, outputs and loss. The .txt file is the data used in the notebook.
